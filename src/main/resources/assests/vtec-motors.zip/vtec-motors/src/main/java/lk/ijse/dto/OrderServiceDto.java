package lk.ijse.dto;


import lombok.*;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString

public class OrderServiceDto {
    private String Order_id;
    private String Service_id;
}
